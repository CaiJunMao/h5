
1. 省市县三级联动。三个select第一个选择省，第二个选择市，第三个选择县。数据来源：		
   http://files.cnblogs.com/files/youngerliu/city_code.js

---
2. 总结今天学习的创建对象的方式，并能说出每种方式的优缺点。

